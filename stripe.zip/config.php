<?php 
// Product Details 
// Minimum amount is $0.50 US 
// Test Stripe API configuration 

define('STRIPE_API_KEY', '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');  
define('STRIPE_PUBLISHABLE_KEY', 'pk_live_51KEzGsDD8ujmfiep8SfoTwyoVTXSYgEurQrBSUVCMlRmj8ozxgh9MdGJjU65gtV5W2pAECazzEFp40NjeKvhNXPa00403eA1T8'); 

define('STRIPE_SUCCESS_URL', 'http://localhost/stripe/success.php'); 
define('STRIPE_CANCEL_URL', 'http://localhost/stripe/cancel.php'); 

// Database configuration   
define('DB_HOST', 'localhost');  
define('DB_USERNAME', 'root');  
define('DB_PASSWORD', '');  
define('DB_NAME', 'stripe'); 
?>



